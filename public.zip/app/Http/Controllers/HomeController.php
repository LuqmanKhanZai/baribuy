<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\UserFund;
use App\Models\UserDocument;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        // admin == 0  mean User else Customer
        if (Auth::user()->admin == 0) {
            $user_id = Auth::user()->id;
            $docs   = UserDocument::where('user_id', $user_id)->get();
            $funds  = UserFund::where('user_id', $user_id)->where('is_active', 1)->first();
            $user = User::with('customerInfo')->find($user_id);
            return view('customer.profile.index', compact('user','docs','funds'));
        } else {
            return redirect()->route('admin.dashboard');
        }
        // return view('home');
    }
}
